1.	Identifikasi Karakteristik dan Kebutuhan Pengguna Sistem
Pengembangan aplikasi perpustakaan Fakultas Sains dan Teknologi ini ditujukan untuk memfasilitasi tiga kelompok pengguna utama yang memiliki karakteristik, perilaku, serta kebutuhan yang spesifik. Berikut adalah hasil identifikasinya:
A. Mahasiswa
Karakteristik: Literasi digital tinggi, membutuhkan kecepatan akses, dan sering menggunakan perangkat mobile (smartphone). Memiliki jadwal yang padat sehingga menuntut proses yang instan.
Kebutuhan Sistem:
Fitur pencarian dan filter buku (ketersediaan fisik & digital).
Sistem booking/reservasi buku dari jarak jauh.
Notifikasi pengingat batas waktu peminjaman dan informasi denda.
Akses riwayat peminjaman untuk referensi tugas/skripsi.
B. Dosen
Karakteristik: Fokus pada eksplorasi literatur akademik dan penelitian. Durasi pinjam cenderung lebih lama. Sering merekomendasikan buku ke mahasiswa atau mengusulkan buku baru.
Kebutuhan Sistem:
Akses mudah ke jurnal, e-book, dan literatur ilmiah spesifik.
Fitur pengajuan (request) pengadaan buku atau jurnal baru.
Kemudahan memperpanjang (extend) masa peminjaman secara online.
C. Pustakawan
Karakteristik: Bertindak sebagai administrator sistem. Mengutamakan efisiensi alur kerja sirkulasi, manajemen inventaris, dan keakuratan data secara real-time.
Kebutuhan Sistem:
Dashboard manajemen sirkulasi untuk memindai (scan) buku yang dipinjam/dikembalikan.
Manajemen katalog (Create, Read, Update, Delete) inventaris perpustakaan.
Rekapitulasi denda, manajemen status anggota, dan pembuatan laporan otomatis.

2.	Analisis Tugas
Berdasarkan identifikasi pengguna, analisis tugas menggunakan pendekatan Hierarchical Task Analysis (HTA) dibagi menjadi tiga skenario utama untuk masing-masing pengguna:
A. Skenario Mahasiswa: Proses Peminjaman Buku
Pencarian: Memasukkan kata kunci di search bar, menerapkan filter, dan mengecek ketersediaan serta lokasi rak fisik.
Reservasi (Booking): Menekan tombol "Pinjam", mengonfirmasi rincian, dan sistem mengeluarkan QR Code sebagai tiket.
Pengambilan: Mahasiswa mendatangi perpustakaan dan menunjukkan QR Code aplikasi kepada pustakawan untuk verifikasi.
B. Skenario Dosen: Proses Pengajuan Pengadaan Literatur Baru
Akses Menu: Masuk ke profil/menu khusus dosen dan memilih fitur "Usulkan Literatur".
Pengisian Formulir: Mengisi detail buku yang dibutuhkan (Judul, Pengarang, Penerbit, dan relevansi dengan Mata Kuliah).
Pemantauan: Melakukan submit dan memantau status pengajuannya (Menunggu/Disetujui/Ditolak) di halaman riwayat.
C. Skenario Pustakawan: Proses Sirkulasi (Acc Peminjaman)
Akses Modul: Login ke dashboard admin dan membuka modul "Sirkulasi/Peminjaman".
Pemindaian (Scanning): Memindai QR Code dari smartphone mahasiswa, dilanjutkan memindai Barcode yang tertempel pada fisik buku menggunakan scanner atau kamera tablet.
Konfirmasi: Sistem mengawinkan data. Pustakawan menekan tombol "Konfirmasi Pinjaman", lalu status buku di dalam sistem otomatis berubah menjadi "Dipinjam".

3.	Struktur Navigasi dan Alur Interaksi
A. Struktur Navigasi (Sitemap)
User Interface (Mahasiswa & Dosen): Beranda (Search & Rekomendasi) → Katalog → Peminjaman Saya → Profil. Khusus Dosen, terdapat tambahan menu "Pengajuan Literatur".
Admin Interface (Pustakawan): Dashboard Admin → Sirkulasi (Scanner) → Manajemen Katalog Inventaris → Laporan & Data Anggota.
B. User Flow (Alur Interaksi)
Flow Peminjaman (Mahasiswa):
Login SSO → Beranda → Ketik Judul di Search Bar → Klik Buku → Klik "Booking" → Konfirmasi → Muncul QR Code Reservasi.
Flow Pengajuan Buku (Dosen):
Login SSO → Menu Profil → Pilih "Usulkan Literatur" → Isi Form (Judul & Pengarang) → Klik "Submit" → Notifikasi Pengajuan Berhasil.
Flow Sirkulasi (Pustakawan):
Login Admin → Dashboard → Menu "Scan Peminjaman" → Arahkan Scanner ke QR Mahasiswa → Scan Barcode Buku Fisik → Klik "Setujui" → Transaksi Selesai.

4.	Wireframe dan Prototype Antarmuka
Desain Halaman Login
Desain Halaman Beranda (Dashboard)
Desain Halaman Pencarian & Detail Buku
Desain Halaman Profil & QR Code Peminjaman)

5.	Penerapan Prinsip Interaksi Manusia dan Komputer 
Rancangan antarmuka ini telah mengacu pada prinsip Heuristik dari Jakob Nielsen guna memastikan User Experience (UX) yang optimal:
Visibility of System Status: Memberikan indikator warna status buku yang jelas (misal: label Hijau untuk "Tersedia", Merah untuk "Sedang Dipinjam") sehingga mahasiswa langsung memahami kondisi tanpa perlu menebak.
Match between System and Real World: Menggunakan ikon yang lazim dipahami (Ikon Magnifying Glass untuk mencari, ikon rak untuk katalog) serta menggunakan bahasa yang familiar bagi mahasiswa (bukan bahasa sistem mesin).
User Control and Freedom: Menyediakan fitur "Batal Booking" bagi mahasiswa jika salah memilih buku, serta tombol Back (Kembali) yang terstruktur jelas di pojok kiri atas antarmuka.
Error Prevention: Sistem selalu memunculkan pop-up konfirmasi sebelum memproses reservasi atau pembayaran denda untuk mencegah klik tidak sengaja. Tombol pinjam otomatis tidak bisa di-klik (disabled) jika mahasiswa sudah mencapai batas maksimal pinjaman.
Aesthetic and Minimalist Design: Menjaga antarmuka tetap bersih (clean layout) dengan pemanfaatan ruang kosong (white-space). Elemen visual difokuskan pada cover buku dan Call-to-Action utama (tombol pinjam) agar pengguna tidak kelebihan beban informasi (cognitive load).

6.	Evaluasi Usability dan Rekomendasi Perbaikan
A. Rencana Evaluasi Evaluasi usabilitas direncanakan menggunakan System Usability Scale (SUS) dan Task-Based Testing. Responden akan terdiri dari 5 mahasiswa, 2 dosen, dan 2 pustakawan agar seluruh modul (End-to-End) dapat teruji oleh perwakilan nyata.

B. Hasil Temuan Simulasi dan Rekomendasi UI/UX
Temuan Masalah (Keparahan: Tinggi): Dosen enggan menggunakan fitur pengajuan buku karena formulir meminta terlalu banyak data detail (ISBN, Edisi, Tahun, dll) yang tidak selalu dihafal dosen.
Rekomendasi Perbaikan: Membuat hanya "Judul" dan "Pengarang" sebagai kolom yang wajib diisi (mandatory), sementara sisanya diubah sifatnya menjadi opsional.
Temuan Masalah (Keparahan: Tinggi): Mahasiswa sering telat mengembalikan buku karena informasi denda hanya terlihat jika mereka sengaja membuka menu Profil.
Rekomendasi Perbaikan: Memunculkan banner alert berwarna merah muda tepat di bagian atas Halaman Beranda agar selalu terlihat sesaat setelah mahasiswa login.
Temuan Masalah (Keparahan: Sedang): Pustakawan mengeluhkan tombol "Setujui" saat memproses peminjaman terlalu kecil jika diakses menggunakan layar sentuh tablet perpustakaan.
Rekomendasi Perbaikan: Memperbesar area sentuh (touch target) minimal berukuran 44x44 piksel dengan batas (margin) yang lebar antar tombol persetujuan dan penolakan.
